"""
Main API module for presentation management.
Provides all public functions for creating, editing, and exporting presentations.
"""

import os
import tempfile
import uuid
from . import storage
from . import markdown_ops

# Sentinel value to detect when a parameter was explicitly provided vs not provided
_NOT_PROVIDED = object()


# Custom exceptions
class PresentationNotFoundError(Exception):
    """Raised when a presentation ID doesn't exist."""
    pass


class InvalidSlideIndexError(Exception):
    """Raised when a slide index is out of range."""
    pass


# Presentation Management

def create_presentation(name, initial_content=None):
    """
    Create a new presentation.
    
    Args:
        name: Presentation name
        initial_content: Optional initial markdown content
        
    Returns:
        tuple: (presentation_id, presentation_dict)
    """
    presentation = storage.create_new_presentation(name, initial_content)
    pres_id = presentation['id']
    slide_count = len(presentation.get('slides', []))
    print(f"Created presentation '{name}' (ID: {pres_id}) with {slide_count} slide(s)")
    return pres_id, presentation


def list_presentations():
    """
    List all presentations.
    
    Returns:
        List of presentation metadata dictionaries
    """
    index = storage.load_index()
    presentations = index.get("presentations", [])
    print(f"Found {len(presentations)} presentation(s):")
    for p in presentations:
        print(f"  - {p.get('name')} (ID: {p.get('id')}, Updated: {p.get('updated_at', 'unknown')})")
    return presentations


def delete_presentation(presentation_id):
    """
    Delete a presentation.
    
    Args:
        presentation_id: Presentation UUID
        
    Returns:
        bool: Success status
    """
    try:
        # Get name before deleting for output
        try:
            presentation = storage.load_presentation(presentation_id)
            name = presentation.get('name', 'Unknown')
        except:
            name = 'Unknown'
        
        storage.delete_presentation_file(presentation_id)
        print(f"Deleted presentation '{name}' (ID: {presentation_id})")
        return True
    except FileNotFoundError:
        print(f"Presentation {presentation_id} not found - nothing to delete")
        return False


def copy_presentation(presentation_id, new_name):
    """
    Create a copy of a presentation.
    
    Args:
        presentation_id: Source presentation UUID
        new_name: Name for the copy
        
    Returns:
        str: New presentation UUID
    """
    try:
        original = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    # Create new presentation with copied slides
    new_id = str(uuid.uuid4())
    now = storage.datetime.utcnow().isoformat() + 'Z'
    
    # Deep copy slides with new IDs
    new_slides = []
    for slide in original.get('slides', []):
        new_slide = {
            "id": str(uuid.uuid4()),
            "order": slide.get('order', 0),
            "title": slide.get('title'),
            "subtitle": slide.get('subtitle'),
            "content": slide.get('content', '')
        }
        new_slides.append(new_slide)
    
    new_presentation = {
        "id": new_id,
        "name": new_name,
        "created_at": now,
        "updated_at": now,
        "slides": new_slides
    }
    
    storage.save_presentation(new_presentation)
    print(f"Copied presentation '{original.get('name')}' to '{new_name}' (New ID: {new_id})")
    return new_id


# Slide Operations

def add_slide(presentation_id, title=None, subtitle=None, content="", position=None):
    """
    Add a new slide to the presentation.
    
    Args:
        presentation_id: Presentation UUID
        title: H1 header text (optional)
        subtitle: H2 header text (optional)
        content: Markdown content (optional)
        position: Insert position (None = append at end)
        
    Returns:
        bool: Success status
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    slides = presentation.get('slides', [])
    
    # Create new slide
    new_slide = {
        "id": str(uuid.uuid4()),
        "order": len(slides) if position is None else position,
        "title": title,
        "subtitle": subtitle,
        "content": content
    }
    
    # Insert at position or append
    if position is None:
        slides.append(new_slide)
    else:
        # Reorder existing slides
        for slide in slides:
            if slide.get('order', 0) >= position:
                slide['order'] = slide.get('order', 0) + 1
        slides.insert(position, new_slide)
    
    # Re-normalize order values
    for i, slide in enumerate(slides):
        slide['order'] = i
    
    presentation['slides'] = slides
    storage.save_presentation(presentation)
    position_str = f"at position {position}" if position is not None else "at end"
    title_str = f"'{title}'" if title else "(no title)"
    print(f"Added slide {title_str} {position_str} to presentation (now {len(slides)} slide(s))")
    return True


def update_slide(presentation_id, slide_index, title=_NOT_PROVIDED, subtitle=_NOT_PROVIDED, content=_NOT_PROVIDED):
    """
    Update slide content. Only provided fields are updated.
    
    Args:
        presentation_id: Presentation UUID
        slide_index: Zero-based slide index
        title: New title (None = clear field, _NOT_PROVIDED = keep existing)
        subtitle: New subtitle (None = clear field, _NOT_PROVIDED = keep existing)
        content: New content (None = clear field, _NOT_PROVIDED = keep existing)
        
    Returns:
        bool: Success status
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    slides = presentation.get('slides', [])
    if slide_index < 0 or slide_index >= len(slides):
        raise InvalidSlideIndexError(f"Slide index {slide_index} out of range")
    
    slide = slides[slide_index]
    old_title = slide.get('title')
    old_subtitle = slide.get('subtitle')
    old_content = slide.get('content', '')
    
    changes = []
    
    # Update title if provided
    if title is not _NOT_PROVIDED:
        if title != old_title:
            slide['title'] = title
            old_str = old_title if old_title is not None else '(none)'
            new_str = title if title is not None else '(cleared)'
            changes.append(f"title: '{old_str}' -> '{new_str}'")
    
    # Update subtitle if provided
    if subtitle is not _NOT_PROVIDED:
        if subtitle != old_subtitle:
            slide['subtitle'] = subtitle
            old_str = old_subtitle if old_subtitle is not None else '(none)'
            new_str = subtitle if subtitle is not None else '(cleared)'
            changes.append(f"subtitle: '{old_str}' -> '{new_str}'")
    
    # Update content if provided
    if content is not _NOT_PROVIDED:
        if content != old_content:
            slide['content'] = content
            changes.append("content updated")
    
    if changes:
        storage.save_presentation(presentation)
        print(f"Updated slide {slide_index}: {', '.join(changes)}")
    else:
        print(f"Slide {slide_index} unchanged (no updates provided)")
    return True


def delete_slide(presentation_id, slide_index):
    """
    Delete a slide from the presentation.
    
    Args:
        presentation_id: Presentation UUID
        slide_index: Zero-based slide index
        
    Returns:
        bool: Success status
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    slides = presentation.get('slides', [])
    if slide_index < 0 or slide_index >= len(slides):
        raise InvalidSlideIndexError(f"Slide index {slide_index} out of range")
    
    # Get slide info before deleting for output
    deleted_slide = slides[slide_index]
    deleted_title = deleted_slide.get('title', '(no title)')
    
    # Create a new list without the deleted slide to ensure proper serialization
    new_slides = [slide for i, slide in enumerate(slides) if i != slide_index]
    
    # Re-normalize order values
    for i, slide in enumerate(new_slides):
        slide['order'] = i
    
    presentation['slides'] = new_slides
    storage.save_presentation(presentation)
    print(f"Deleted slide {slide_index} ('{deleted_title}') from presentation (now {len(new_slides)} slide(s))")
    return True


def get_slide(presentation_id, slide_index):
    """
    Get slide content and metadata.
    
    Args:
        presentation_id: Presentation UUID
        slide_index: Zero-based slide index
        
    Returns:
        dict: Slide structure with title, subtitle, content, raw_markdown
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    slides = presentation.get('slides', [])
    if slide_index < 0 or slide_index >= len(slides):
        raise InvalidSlideIndexError(f"Slide index {slide_index} out of range")
    
    slide = slides[slide_index]
    # Get raw values to ensure we're reading correctly
    raw_title = slide.get('title')
    raw_subtitle = slide.get('subtitle')
    raw_content = slide.get('content', '')
    
    raw_markdown = markdown_ops.assemble_slide_markdown(
        raw_title,
        raw_subtitle,
        raw_content
    )
    
    result = {
        "index": slide_index,
        "id": slide.get('id'),
        "title": raw_title,
        "subtitle": raw_subtitle,
        "content": raw_content,
        "raw_markdown": raw_markdown
    }
    
    print(f"\n=== Slide {slide_index} ===")
    print(f"ID: {result['id']}")
    print(f"Title: {raw_title if raw_title is not None else '(no title)'}")
    print(f"Subtitle: {raw_subtitle if raw_subtitle is not None else '(no subtitle)'}")
    print(f"Content:")
    content = result['content']
    if content:
        print(content)
    else:
        print("  (no content)")
    print(f"\nRaw Markdown:")
    print(raw_markdown)
    print("=" * 50)
    
    return result


def get_all_slides(presentation_id):
    """
    Get all slides in the presentation.
    
    Args:
        presentation_id: Presentation UUID
        
    Returns:
        list: List of slide dictionaries
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    slides = presentation.get('slides', [])
    result = []
    for i, slide in enumerate(slides):
        raw_markdown = markdown_ops.assemble_slide_markdown(
            slide.get('title'),
            slide.get('subtitle'),
            slide.get('content', '')
        )
        result.append({
            "index": i,
            "id": slide.get('id'),
            "title": slide.get('title'),
            "subtitle": slide.get('subtitle'),
            "content": slide.get('content', ''),
            "raw_markdown": raw_markdown
        })
    
    print(f"\nRetrieved {len(result)} slide(s):\n")
    for slide_data in result:
        print(f"=== Slide {slide_data['index']} ===")
        print(f"ID: {slide_data['id']}")
        title = slide_data['title']
        print(f"Title: {title if title is not None else '(no title)'}")
        subtitle = slide_data['subtitle']
        print(f"Subtitle: {subtitle if subtitle is not None else '(no subtitle)'}")
        print(f"Content:")
        content = slide_data['content']
        if content:
            print(content)
        else:
            print("  (no content)")
        print(f"\nRaw Markdown:")
        print(slide_data['raw_markdown'])
        print("=" * 50)
        print()
    
    return result


def reorder_slides(presentation_id, new_order):
    """
    Reorder slides in the presentation.
    
    Args:
        presentation_id: Presentation UUID
        new_order: List of slide indices in desired order
        
    Returns:
        bool: Success status
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    slides = presentation.get('slides', [])
    
    # Validate indices
    if len(new_order) != len(slides):
        raise ValueError(f"new_order length {len(new_order)} doesn't match slide count {len(slides)}")
    
    if set(new_order) != set(range(len(slides))):
        raise ValueError("new_order must contain all slide indices exactly once")
    
    # Reorder slides
    reordered = [slides[i] for i in new_order]
    
    # Update order values
    for i, slide in enumerate(reordered):
        slide['order'] = i
    
    presentation['slides'] = reordered
    storage.save_presentation(presentation)
    print(f"Reordered {len(reordered)} slide(s) - new order: {new_order}")
    return True


def duplicate_slide(presentation_id, slide_index):
    """
    Create a copy of a slide.
    
    Args:
        presentation_id: Presentation UUID
        slide_index: Zero-based slide index to duplicate
        
    Returns:
        bool: Success status
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    slides = presentation.get('slides', [])
    if slide_index < 0 or slide_index >= len(slides):
        raise InvalidSlideIndexError(f"Slide index {slide_index} out of range")
    
    original_slide = slides[slide_index]
    new_slide = {
        "id": str(uuid.uuid4()),
        "order": slide_index + 1,
        "title": original_slide.get('title'),
        "subtitle": original_slide.get('subtitle'),
        "content": original_slide.get('content', '')
    }
    
    # Reorder slides after insertion point
    for slide in slides[slide_index + 1:]:
        slide['order'] = slide.get('order', 0) + 1
    
    slides.insert(slide_index + 1, new_slide)
    
    # Re-normalize order values
    for i, slide in enumerate(slides):
        slide['order'] = i
    
    presentation['slides'] = slides
    storage.save_presentation(presentation)
    original_title = original_slide.get('title', '(no title)')
    print(f"Duplicated slide {slide_index} ('{original_title}') - new slide at position {slide_index + 1} (now {len(slides)} slide(s))")
    return True


# Content Helpers

def append_to_slide(presentation_id, slide_index, markdown_content):
    """
    Append content to an existing slide.
    
    Args:
        presentation_id: Presentation UUID
        slide_index: Zero-based slide index
        markdown_content: Content to append
        
    Returns:
        bool: Success status
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    slides = presentation.get('slides', [])
    if slide_index < 0 or slide_index >= len(slides):
        raise InvalidSlideIndexError(f"Slide index {slide_index} out of range")
    
    slide = slides[slide_index]
    current_content = slide.get('content', '')
    new_content = current_content + "\n\n" + markdown_content if current_content else markdown_content
    slide['content'] = new_content
    
    storage.save_presentation(presentation)
    title_str = slide.get('title', '(no title)')
    print(f"Appended content to slide {slide_index} ('{title_str}')")
    return True


def prepend_to_slide(presentation_id, slide_index, markdown_content):
    """
    Prepend content to an existing slide.
    
    Args:
        presentation_id: Presentation UUID
        slide_index: Zero-based slide index
        markdown_content: Content to prepend
        
    Returns:
        bool: Success status
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    slides = presentation.get('slides', [])
    if slide_index < 0 or slide_index >= len(slides):
        raise InvalidSlideIndexError(f"Slide index {slide_index} out of range")
    
    slide = slides[slide_index]
    current_content = slide.get('content', '')
    new_content = markdown_content + "\n\n" + current_content if current_content else markdown_content
    slide['content'] = new_content
    
    storage.save_presentation(presentation)
    title_str = slide.get('title', '(no title)')
    print(f"Prepended content to slide {slide_index} ('{title_str}')")
    return True


# Export & Generation

def generate_markdown(presentation_id, output_file):
    """
    Generate markdown file from presentation.
    
    Args:
        presentation_id: Presentation UUID
        output_file: Path for output .md file
        
    Returns:
        bool: Success status
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    slides = presentation.get('slides', [])
    markdown_text = markdown_ops.assemble_slides_to_markdown(slides)
    
    # Ensure output directory exists
    output_dir = os.path.dirname(os.path.abspath(output_file))
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(markdown_text)
    
    slide_count = len(slides)
    print(f"Generated markdown file '{output_file}' with {slide_count} slide(s)")
    return True


def generate_pptx(presentation_id, output_file, theme_file=None):
    """
    Generate PowerPoint file from presentation.
    
    Args:
        presentation_id: Presentation UUID
        output_file: Path for output .pptx file
        theme_file: Path to theme JSON file (optional)
        
    Returns:
        bool: Success status
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    # Generate markdown to temp file
    slides = presentation.get('slides', [])
    markdown_text = markdown_ops.assemble_slides_to_markdown(slides)
    
    # Create temp markdown file in same directory as output (for image path resolution)
    output_dir = os.path.dirname(os.path.abspath(output_file))
    if not output_dir:
        output_dir = os.getcwd()
    
    temp_md = tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False, dir=output_dir, encoding='utf-8')
    temp_md.write(markdown_text)
    temp_md.close()
    
    try:
        # Import PowerPointGenerator from the existing script
        # Try multiple strategies to find the generator
        import importlib.util
        
        PowerPointGenerator = None
        
        # Strategy 1: Try to import as a module (if it's in Python path)
        try:
            from md_to_pptx_professional import PowerPointGenerator
        except ImportError:
            pass
        
        # Strategy 2: Try common relative paths from the module location
        if PowerPointGenerator is None:
            # Get the module directory (where api.py is located)
            module_dir = os.path.dirname(os.path.abspath(__file__))
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            possible_paths = [
                # Try in the same directory as the module (most likely location)
                os.path.join(module_dir, 'md_to_pptx_professional.py'),
                # Try in a Resources folder relative to module
                os.path.join(module_dir, '..', 'Resources', 'md_to_pptx_professional.py'),
                # Try the known location in the codebase
                os.path.join(
                    base_dir, 'server', 'ContentFiles', '133707e1-7c82-49a4-9395-57e25e22376a',
                    'notebooks', '12a000b6-1436-4058-9d06-d085eb5e78b5', 'Output',
                    'md_to_pptx_professional.py'
                ),
                # Try in current working directory
                os.path.join(os.getcwd(), 'md_to_pptx_professional.py'),
            ]
            
            for generator_path in possible_paths:
                if os.path.exists(generator_path):
                    spec = importlib.util.spec_from_file_location("md_to_pptx_professional", generator_path)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    PowerPointGenerator = module.PowerPointGenerator
                    break
        
        if PowerPointGenerator is None:
            raise ImportError(
                "Could not find PowerPointGenerator (md_to_pptx_professional.py). "
                "Please ensure the file is accessible in the Python path or provide the path."
            )
        
        # Generate PPTX
        generator = PowerPointGenerator(temp_md.name, output_file, theme_file=theme_file)
        generator.generate()
        
        slide_count = len(slides)
        theme_str = f" with theme '{theme_file}'" if theme_file else ""
        print(f"Generated PowerPoint file '{output_file}' with {slide_count} slide(s){theme_str}")
        return True
    finally:
        # Clean up temp file
        try:
            os.unlink(temp_md.name)
        except:
            pass


def import_from_markdown(markdown_file, presentation_name=None):
    """
    Import an existing markdown file as a new presentation.
    
    Args:
        markdown_file: Path to markdown file to import
        presentation_name: Name for new presentation (None = use filename)
        
    Returns:
        str: New presentation UUID
    """
    if not os.path.exists(markdown_file):
        raise FileNotFoundError(f"Markdown file {markdown_file} not found")
    
    with open(markdown_file, 'r', encoding='utf-8') as f:
        markdown_text = f.read()
    
    if presentation_name is None:
        presentation_name = os.path.splitext(os.path.basename(markdown_file))[0]
    
    presentation_id, _ = create_presentation(presentation_name, markdown_text)
    print(f"Imported markdown file '{markdown_file}' as presentation '{presentation_name}' (ID: {presentation_id})")
    return presentation_id


# Utility Functions

def get_slide_count(presentation_id):
    """
    Get the number of slides in the presentation.
    
    Args:
        presentation_id: Presentation UUID
        
    Returns:
        int: Number of slides
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    count = len(presentation.get('slides', []))
    print(f"Presentation has {count} slide(s)")
    return count


def search_slides(presentation_id, search_text):
    """
    Search for slides containing the given text.
    
    Args:
        presentation_id: Presentation UUID
        search_text: Text to search for
        
    Returns:
        list: List of slide indices containing the text
    """
    try:
        presentation = storage.load_presentation(presentation_id)
    except FileNotFoundError:
        raise PresentationNotFoundError(f"Presentation {presentation_id} not found")
    
    search_lower = search_text.lower()
    matching_indices = []
    
    slides = presentation.get('slides', [])
    for i, slide in enumerate(slides):
        # Search in title, subtitle, and content
        searchable_text = ' '.join([
            slide.get('title', ''),
            slide.get('subtitle', ''),
            slide.get('content', '')
        ]).lower()
        
        if search_lower in searchable_text:
            matching_indices.append(i)
    
    if matching_indices:
        print(f"Found '{search_text}' in {len(matching_indices)} slide(s): {matching_indices}")
    else:
        print(f"No slides found containing '{search_text}'")
    return matching_indices

