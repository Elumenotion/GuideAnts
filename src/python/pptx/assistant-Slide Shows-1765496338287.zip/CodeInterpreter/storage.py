"""
Storage module for presentation persistence.
Handles file I/O and path management for presentation JSON files.
"""

import os
import json
import uuid
from datetime import datetime
from pathlib import Path


# Module directory detection
_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
STORAGE_DIR = os.path.join(_MODULE_DIR, "presentations")
INDEX_FILE = os.path.join(STORAGE_DIR, ".index.json")


def ensure_storage_dir():
    """Ensure the storage directory exists."""
    os.makedirs(STORAGE_DIR, exist_ok=True)


def get_presentation_file(presentation_id):
    """Get the full path to a presentation JSON file."""
    ensure_storage_dir()
    return os.path.join(STORAGE_DIR, f"{presentation_id}.json")


def load_presentation(presentation_id):
    """Load a presentation from storage."""
    file_path = get_presentation_file(presentation_id)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Presentation {presentation_id} not found")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_presentation(presentation):
    """Save a presentation to storage."""
    ensure_storage_dir()
    presentation['updated_at'] = datetime.utcnow().isoformat() + 'Z'
    
    file_path = get_presentation_file(presentation['id'])
    
    # Atomic write: write to temp file, then rename
    temp_path = file_path + '.tmp'
    with open(temp_path, 'w', encoding='utf-8') as f:
        json.dump(presentation, f, indent=2, ensure_ascii=False)
    
    os.replace(temp_path, file_path)
    
    # Update index
    update_index(presentation['id'], presentation['name'], presentation['updated_at'])


def delete_presentation_file(presentation_id):
    """Delete a presentation file."""
    file_path = get_presentation_file(presentation_id)
    if os.path.exists(file_path):
        os.remove(file_path)
        remove_from_index(presentation_id)


def create_new_presentation(name, initial_content=None):
    """Create a new presentation structure."""
    presentation_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat() + 'Z'
    
    slides = []
    if initial_content:
        # Parse initial content into slides if provided
        from .markdown_ops import parse_markdown_to_slides
        slides = parse_markdown_to_slides(initial_content)
    
    presentation = {
        "id": presentation_id,
        "name": name,
        "created_at": now,
        "updated_at": now,
        "slides": slides
    }
    
    save_presentation(presentation)
    return presentation


def load_index():
    """Load the presentations index."""
    ensure_storage_dir()
    if not os.path.exists(INDEX_FILE):
        return {"presentations": []}
    
    try:
        with open(INDEX_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {"presentations": []}


def save_index(index_data):
    """Save the presentations index."""
    ensure_storage_dir()
    temp_path = INDEX_FILE + '.tmp'
    with open(temp_path, 'w', encoding='utf-8') as f:
        json.dump(index_data, f, indent=2, ensure_ascii=False)
    os.replace(temp_path, INDEX_FILE)


def update_index(presentation_id, name, updated_at):
    """Update or add entry in index."""
    index = load_index()
    presentations = index.get("presentations", [])
    
    # Find existing entry
    found = False
    for p in presentations:
        if p["id"] == presentation_id:
            p["name"] = name
            p["updated_at"] = updated_at
            found = True
            break
    
    if not found:
        presentations.append({
            "id": presentation_id,
            "name": name,
            "file": f"{presentation_id}.json",
            "updated_at": updated_at
        })
    
    index["presentations"] = presentations
    save_index(index)


def remove_from_index(presentation_id):
    """Remove entry from index."""
    index = load_index()
    presentations = index.get("presentations", [])
    index["presentations"] = [p for p in presentations if p["id"] != presentation_id]
    save_index(index)


def get_all_presentation_ids():
    """Get all presentation IDs from index."""
    index = load_index()
    return [p["id"] for p in index.get("presentations", [])]

