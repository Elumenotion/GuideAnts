# Presentation API Module - LLM Usage Instructions

## Overview

The `pptx` module provides a simple API for creating and managing presentations stored as structured data. Presentations are persisted as JSON files in the module's directory, and markdown/PPTX files are generated on-demand in the executing script's location.

## Importing the Module

**IMPORTANT:** `contextOptions` is NOT a Python variable. It is information provided in the system context/prompt. You must extract the path strings from that information and use them directly in your Python code. Do NOT try to access `contextOptions` as a Python variable - it will cause a `NameError`.

When writing Python scripts that use this module:

1. **From the system context**, find the entry in `contextOptions.files` where the filename is `__init__.py` in a Resources directory
2. **Extract the exact path string** from that entry (this is a string value, not a variable reference)
3. **Use that exact path string directly** in your Python code with `importlib`

```python
import importlib.util
import os
import sys

# Extract the exact path string from contextOptions.files where filename is "__init__.py"
# The path will be in a Resources directory
# Do NOT use contextOptions.files as a variable - extract the path string and use it directly
init_py_path = "/actual/path/to/Resources/.../__init__.py"  # Replace with actual path from contextOptions.files

# Add the PARENT directory to sys.path so the module can be imported as a package
# This allows relative imports (from .api import ...) to work correctly
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(init_py_path)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import the slides module as a package
# The module directory name in the path determines the import name (e.g., if path contains "slides", import as 'slides')
# Extract the directory name from the path to determine the module name
module_dir_name = os.path.basename(os.path.dirname(init_py_path))
slides_module = importlib.import_module(module_dir_name)

# Extract functions from the module
create_presentation = slides_module.create_presentation
add_slide = slides_module.add_slide
update_slide = slides_module.update_slide
delete_slide = slides_module.delete_slide
get_slide = slides_module.get_slide
get_all_slides = slides_module.get_all_slides
reorder_slides = slides_module.reorder_slides
duplicate_slide = slides_module.duplicate_slide
append_to_slide = slides_module.append_to_slide
prepend_to_slide = slides_module.prepend_to_slide
generate_markdown = slides_module.generate_markdown
generate_pptx = slides_module.generate_pptx
import_from_markdown = slides_module.import_from_markdown
get_slide_count = slides_module.get_slide_count
search_slides = slides_module.search_slides
list_presentations = slides_module.list_presentations
delete_presentation = slides_module.delete_presentation
copy_presentation = slides_module.copy_presentation
```

## Core Concepts

1. **Presentations are stored as JSON** in the module's directory (not in your script's CWD)
2. **Markdown/PPTX are generated on-demand** in locations you specify
3. **Image paths are stored as-is** - they will be resolved relative to the generated markdown file location which is always your CWD unless explicit instructions from the user say otherwise
4. **Layout detection is automatic** - you provide markdown content, the system determines the slide layout
5. **User Communication:** When talking to the user, always refer to presentations by their **name**, not their ID. Internally, your code uses presentation IDs (UUIDs), but when communicating with the user, use the presentation name. For example, say "I've added a slide to 'My Presentation'" not "I've added a slide to presentation abc-123-def".

## API Functions Reference

### Presentation Management

#### `create_presentation(name, initial_content=None)`
Creates a new presentation.

**Parameters:**
- `name` (str): Presentation name
- `initial_content` (str, optional): Initial markdown content

**Returns:**
- `tuple`: `(presentation_id, presentation_dict)`

**Example:**
```python
pres_id, pres_data = create_presentation("My Presentation")
```

#### `list_presentations()`
Lists all presentations.

**Returns:**
- `list`: List of presentation metadata dictionaries with `id`, `name`, `updated_at`, etc.

**Note:** When showing presentations to the user, display them by name. Use the `id` internally for API calls, but refer to presentations by name when communicating with the user.

#### `delete_presentation(presentation_id)`
Deletes a presentation.

**Parameters:**
- `presentation_id` (str): Presentation UUID

**Returns:**
- `bool`: Success status

#### `copy_presentation(presentation_id, new_name)`
Creates a copy of a presentation.

**Parameters:**
- `presentation_id` (str): Source presentation UUID
- `new_name` (str): Name for the copy

**Returns:**
- `str`: New presentation UUID

### Slide Operations

#### `add_slide(presentation_id, title=None, subtitle=None, content="", position=None)`
Adds a new slide to the presentation.

**Parameters:**
- `presentation_id` (str): Presentation UUID
- `title` (str, optional): H1 header text
- `subtitle` (str, optional): H2 header text
- `content` (str, optional): Markdown content
- `position` (int, optional): Insert position (None = append at end)

**Returns:**
- `bool`: Success status

**Examples:**
```python
# Simple title slide
add_slide(pres_id, title="Welcome")

# Title with content
add_slide(pres_id, 
    title="Overview", 
    content="This is the overview content.")

# Table slide (layout auto-detected)
add_slide(pres_id,
    title="Data",
    content="| Column 1 | Column 2 |\n|----------|----------|\n| Value 1 | Value 2 |")

# Bullet list slide (layout auto-detected)
add_slide(pres_id,
    title="Features",
    content="- Feature 1\n- Feature 2\n  - Nested item")

# Code block slide (layout auto-detected)
add_slide(pres_id,
    title="Example",
    content="```python\ndef hello():\n    print('world')\n```")

# Image slide (layout auto-detected)
add_slide(pres_id,
    title="Dashboard",
    content="![Dashboard](./images/dashboard.png)")

# Insert at specific position
add_slide(pres_id, title="New Slide", position=2)
```

#### `update_slide(presentation_id, slide_index, title=None, subtitle=None, content=None)`
Updates slide content. Only provided fields are updated.

**Parameters:**
- `presentation_id` (str): Presentation UUID
- `slide_index` (int): Zero-based slide index
- `title` (str, optional): New title (None = keep existing)
- `subtitle` (str, optional): New subtitle (None = keep existing)
- `content` (str, optional): New content (None = keep existing)

**Returns:**
- `bool`: Success status

**Example:**
```python
# Update only content
update_slide(pres_id, 0, content="Updated content here")

# Update title only
update_slide(pres_id, 0, title="New Title")
```

#### `delete_slide(presentation_id, slide_index)`
Deletes a slide from the presentation.

**Parameters:**
- `presentation_id` (str): Presentation UUID
- `slide_index` (int): Zero-based slide index

**Returns:**
- `bool`: Success status

#### `get_slide(presentation_id, slide_index)`
Gets slide content and metadata.

**Parameters:**
- `presentation_id` (str): Presentation UUID
- `slide_index` (int): Zero-based slide index

**Returns:**
- `dict`: Slide structure with `title`, `subtitle`, `content`, `raw_markdown`, `index`, `id`

#### `get_all_slides(presentation_id)`
Gets all slides in the presentation.

**Parameters:**
- `presentation_id` (str): Presentation UUID

**Returns:**
- `list`: List of slide dictionaries

#### `reorder_slides(presentation_id, new_order)`
Reorders slides in the presentation.

**Parameters:**
- `presentation_id` (str): Presentation UUID
- `new_order` (list): List of slide indices in desired order

**Returns:**
- `bool`: Success status

**Example:**
```python
# Reverse the order
reorder_slides(pres_id, [2, 1, 0])
```

#### `duplicate_slide(presentation_id, slide_index)`
Creates a copy of a slide.

**Parameters:**
- `presentation_id` (str): Presentation UUID
- `slide_index` (int): Zero-based slide index to duplicate

**Returns:**
- `bool`: Success status

### Content Helpers

#### `append_to_slide(presentation_id, slide_index, markdown_content)`
Appends content to an existing slide.

**Parameters:**
- `presentation_id` (str): Presentation UUID
- `slide_index` (int): Zero-based slide index
- `markdown_content` (str): Content to append

**Returns:**
- `bool`: Success status

#### `prepend_to_slide(presentation_id, slide_index, markdown_content)`
Prepends content to an existing slide.

**Parameters:**
- `presentation_id` (str): Presentation UUID
- `slide_index` (int): Zero-based slide index
- `markdown_content` (str): Content to prepend

**Returns:**
- `bool`: Success status

### Export & Generation

#### `generate_markdown(presentation_id, output_file)`
Generates markdown file from presentation.

**Parameters:**
- `presentation_id` (str): Presentation UUID
- `output_file` (str): Path for output .md file (relative to executing script's CWD)

**Returns:**
- `bool`: Success status

**Example:**
```python
# Generate markdown in current working directory
generate_markdown(pres_id, "output.md")

# Generate in subdirectory
generate_markdown(pres_id, "./output/presentation.md")
```

#### `generate_pptx(presentation_id, output_file, theme_file=None)`
Generates PowerPoint file from presentation.

**Parameters:**
- `presentation_id` (str): Presentation UUID
- `output_file` (str): Path for output .pptx file (relative to executing script's CWD)
- `theme_file` (str, optional): Exact path string from contextOptions.files where filename is `pptx_theme.json` or similar

**Returns:**
- `bool`: Success status

**Example:**
```python
# Generate PPTX with default theme
generate_pptx(pres_id, "output.pptx")

# Generate with custom theme
# Extract exact path string from contextOptions.files where filename is "pptx_theme.json"
# IMPORTANT: Replace with actual path string from system context, do NOT use contextOptions as a variable
theme_path = "/actual/path/to/pptx_theme.json"  # Replace with actual path from contextOptions.files
generate_pptx(pres_id, "output.pptx", theme_file=theme_path)
```

**Note:** 
- The `generate_pptx` function automatically finds the `PowerPointGenerator` class from `md_to_pptx_professional.py`. From the system context, find the path in `contextOptions.files` for filename `md_to_pptx_professional.py` - the function will use that path automatically.
- Theme files (like `pptx_theme.json`) are now located in the module directory (`src/python/pptx/`). They can also be in the same directory as `md_to_pptx_professional.py`. Extract the exact path string from `contextOptions.files` where the filename matches the theme file you want to use (e.g., `pptx_theme.json`, `pptx_theme_blue.json`). **IMPORTANT:** Extract the path string from the system context and use it as a string literal - do NOT try to access `contextOptions` as a Python variable.
- If `theme_file` is `None`, the PowerPointGenerator will auto-discover theme files using its own logic (it searches the same directory as the markdown file, the script directory, and current working directory).

#### `import_from_markdown(markdown_file, presentation_name=None)`
Imports an existing markdown file as a new presentation.

**Parameters:**
- `markdown_file` (str): Exact path string from contextOptions.files where filename ends with `.md` (extract from system context, use as string literal)
- `presentation_name` (str, optional): Name for new presentation (None = use filename)

**Returns:**
- `str`: New presentation UUID

**Example:**
```python
# Extract exact path string from contextOptions.files where filename ends with ".md"
# IMPORTANT: Replace with actual path string from system context, do NOT use contextOptions as a variable
md_path = "/actual/path/to/file.md"  # Replace with actual path from contextOptions.files
pres_id = import_from_markdown(md_path, "Imported Presentation")
```

### Utility Functions

#### `get_slide_count(presentation_id)`
Gets the number of slides in the presentation.

**Parameters:**
- `presentation_id` (str): Presentation UUID

**Returns:**
- `int`: Number of slides

#### `search_slides(presentation_id, search_text)`
Searches for slides containing the given text.

**Parameters:**
- `presentation_id` (str): Presentation UUID
- `search_text` (str): Text to search for

**Returns:**
- `list`: List of slide indices containing the text

## Working with Files from contextOptions

**IMPORTANT:** `contextOptions` is NOT a Python variable. Extract path strings from the system context and use them directly as string literals in your code.

When referencing files (themes, markdown imports):

1. **From the system context**, find the entry in `contextOptions.files` for the filename you need (e.g., `pptx_theme.json`, `md_to_pptx_professional.py`)
2. **Extract the exact path string** from that entry (this is a string value, not a variable reference)
3. **Use that exact path string directly** in your Python code as a string literal - do not modify, convert, or make relative
4. **Theme files stay in their original location** - you do NOT need to copy them, just reference them by path
5. **For images in slide content**, use paths relative to where the markdown will be generated (not from contextOptions)

**Example:**
```python
# From the system context, find the entry in contextOptions.files where filename is "pptx_theme.json"
# Extract the exact path string and use it directly as a string literal
# Do NOT use contextOptions.files as a variable - extract the path and use it directly
theme_path = "/actual/path/to/pptx_theme.json"  # Replace with actual path from contextOptions.files

# Use the exact path string
generate_pptx(pres_id, "output.pptx", theme_file=theme_path)
```

## Working with Presentation Names vs IDs

**IMPORTANT:** When communicating with users, always refer to presentations by **name**, not ID. Internally, your code uses presentation IDs (UUIDs), but when talking to the user, use the presentation name.

**Helper function to find presentation ID by name:**
```python
def get_presentation_id_by_name(presentation_name):
    """Find presentation ID by name - use this to convert user-friendly names to IDs for API calls"""
    presentations = list_presentations()
    for p in presentations:
        if p.get('name') == presentation_name:
            return p.get('id')
    return None

# Example: User asks to add a slide to "My Presentation"
presentation_name = "My Presentation"  # From user request
pres_id = get_presentation_id_by_name(presentation_name)
if pres_id:
    add_slide(pres_id, title="New Slide")
    # Tell user: "I've added a slide to 'My Presentation'"
else:
    # Tell user: "I couldn't find a presentation named 'My Presentation'"
```

**When communicating with the user:**
- ✅ Say: "I've added a slide to 'Quarterly Review'"
- ❌ Don't say: "I've added a slide to presentation abc-123-def-456"

## Complete Usage Example

```python
# Import the module
# Extract exact path string from contextOptions.files where filename is "__init__.py"
# Use importlib method shown above to load the module

# Create a new presentation
presentation_name = "Quarterly Review"
pres_id, pres_data = create_presentation(presentation_name)
# Note: Store pres_id internally, but refer to it as "Quarterly Review" when talking to user

# Add various slide types (layout auto-detected)
add_slide(pres_id, title="Q4 2024 Review")
# Tell user: "I've added a slide titled 'Q4 2024 Review' to 'Quarterly Review'"

add_slide(pres_id,
    title="Executive Summary",
    subtitle="Key Highlights",
    content="- Revenue up 20%\n- New customers: 500\n- Product launch successful")

add_slide(pres_id,
    title="Sales Data",
    content="| Product | Q3 | Q4 |\n|---------|----|----|\n| A | $100K | $120K |\n| B | $80K | $95K |")

add_slide(pres_id,
    title="Code Example",
    content="```python\ndef calculate():\n    return 42\n```")

# Add slide with image (path relative to where markdown will be generated)
add_slide(pres_id,
    title="Dashboard",
    content="![Dashboard](./images/dashboard.png)")

# Edit a slide
update_slide(pres_id, 0, title="Q4 2024 Review - Updated")

# Check slide count
count = get_slide_count(pres_id)
# Tell user: "The 'Quarterly Review' presentation has {count} slides"

# Generate outputs (files created in current working directory)
generate_markdown(pres_id, "quarterly_review.md")

# Generate PPTX (optionally with theme from contextOptions.files)
# Extract exact path string from contextOptions.files where filename is "pptx_theme.json"
# IMPORTANT: Replace with actual path string from system context, do NOT use contextOptions as a variable
theme_path = "/actual/path/to/pptx_theme.json"  # Replace with actual path from contextOptions.files, optional
generate_pptx(pres_id, "quarterly_review.pptx", theme_file=theme_path)
```

## Image Path Handling

When adding slides with images:

1. **Image paths are stored exactly as you provide them**
2. **When generating markdown**, the markdown file is created in the location you specify
3. **Image paths in the markdown are relative to the markdown file location**
4. **PowerPointGenerator resolves images relative to the generated markdown file**

**Example:**
```python
# Use image paths relative to where the markdown file will be generated
add_slide(pres_id,
    title="Chart",
    content="![Chart](./images/chart.png)")

generate_markdown(pres_id, "./output.md")
# Image will be resolved relative to the output.md file location
```

## Error Handling

The module raises custom exceptions:

- `PresentationNotFoundError`: Presentation ID doesn't exist
- `InvalidSlideIndexError`: Slide index is out of range
- `FileNotFoundError`: File operations fail
- `ValueError`: Invalid parameters
- `ImportError`: Could not find PowerPointGenerator (for `generate_pptx`)

**Example:**
```python
try:
    pres_id, _ = create_presentation("Test")
    add_slide(pres_id, title="Slide 1")
    generate_pptx(pres_id, "output.pptx")
except PresentationNotFoundError as e:
    print(f"Presentation not found: {e}")
except ImportError as e:
    print(f"Could not find PowerPointGenerator: {e}")
```

## Supported Markdown Elements

The module supports all standard markdown elements that the PowerPointGenerator recognizes:

- **Headers**: `# Title` (H1), `## Subtitle` (H2), `### Heading` (H3)
- **Bullet lists**: `-` or `*` (supports nesting via indentation)
- **Numbered lists**: `1.`, `2.`, etc.
- **Code blocks**: Triple backticks (```)
- **Tables**: Pipe-delimited (`| col1 | col2 |`)
- **Images**: `![alt](path)` (supports URLs and local paths)
- **Paragraphs**: Regular text
- **Bold text**: `**bold**` (within paragraphs and bullets)
- **Slide breaks**: `---` (horizontal rule - used when importing)

## Layout Detection

The system automatically detects slide layouts based on content:

- **Title slide**: H1 + 1 image + no content → `title_slide`
- **Title + subtitle slide**: H1 + H2 + 1 image + no content → `title_slide_subtitle`
- **Table slide**: Contains table → `table`
- **Code slide**: Contains code block → `code`
- **Image-focused**: Has images, no content → `image_focused`
- **Image + content**: Has images + content → `image_content`
- **Bullet slide**: Contains bullet list → `bullets`
- **Title + subtitle**: Has H1 + H2 → `title_subtitle`
- **Default**: Standard title + content → `title_content`

You don't need to specify slide types - just provide the markdown content and the system determines the appropriate layout.

## Best Practices

1. **Use descriptive presentation names** for easier management
2. **Always refer to presentations by name when communicating with users** - use IDs internally in your code, but names when talking to the user
3. **Store image paths relative to where markdown will be generated**
4. **Extract exact path strings from contextOptions.files in the system context** - search by filename, extract the path string, and use it directly as a string literal in your code. **Do NOT try to access `contextOptions` as a Python variable** - it will cause a `NameError`.
5. **Check slide count** before accessing slides by index
6. **Handle exceptions** when working with presentations
7. **Generate markdown first** to verify content before generating PPTX

## Notes

- Presentations are persisted in the module's directory, not your script's CWD
- The module automatically creates the storage directory if it doesn't exist
- All file paths for images should be relative to where the markdown file will be generated
- The PowerPointGenerator is automatically located when generating PPTX files
- Slide indices are zero-based (first slide is index 0)

**IMPORTANT - YOUR CWD is `output` DON'T BE CONFUSED BY RELATIVE PATHS FROM OTHER OPERATIONS CONTAINING `/output/` THAT IS YOUR CWD**
