"""
Markdown operations module.
Handles parsing markdown into slide structures and assembling slides into markdown.
"""

import re


def parse_slide_markdown(slide_md):
    """
    Parse a slide's markdown to extract title, subtitle, and content.
    
    Args:
        slide_md: Markdown string for a single slide
        
    Returns:
        dict with keys: title, subtitle, content
    """
    lines = slide_md.strip().split('\n')
    title = None
    subtitle = None
    content_lines = []
    
    for line in lines:
        stripped = line.strip()
        if stripped.startswith('# '):
            title = stripped[2:].strip()
        elif stripped.startswith('## '):
            subtitle = stripped[3:].strip()
        else:
            content_lines.append(line)
    
    content = '\n'.join(content_lines).strip()
    return {
        "title": title,
        "subtitle": subtitle,
        "content": content
    }


def assemble_slide_markdown(title, subtitle, content):
    """
    Assemble markdown string from title, subtitle, and content components.
    
    Args:
        title: H1 header text (optional)
        subtitle: H2 header text (optional)
        content: Markdown content (optional)
        
    Returns:
        Complete markdown string for the slide
    """
    parts = []
    if title:
        parts.append(f"# {title}")
    if subtitle:
        parts.append(f"## {subtitle}")
    if content:
        parts.append(content.strip())
    
    return "\n\n".join(parts)


def parse_markdown_to_slides(markdown_text):
    """
    Parse full markdown text into slide structures.
    Slides are separated by '---' (horizontal rule).
    
    Args:
        markdown_text: Full markdown content
        
    Returns:
        List of slide dictionaries with id, order, title, subtitle, content
    """
    import uuid
    
    # Split by slide separators
    slide_texts = re.split(r'\n---+\n', markdown_text)
    
    slides = []
    for i, slide_text in enumerate(slide_texts):
        slide_text = slide_text.strip()
        if not slide_text:
            continue
        
        parsed = parse_slide_markdown(slide_text)
        slides.append({
            "id": str(uuid.uuid4()),
            "order": i,
            "title": parsed["title"],
            "subtitle": parsed["subtitle"],
            "content": parsed["content"]
        })
    
    return slides


def assemble_slides_to_markdown(slides):
    """
    Assemble slides into full markdown text with separators.
    
    Args:
        slides: List of slide dictionaries
        
    Returns:
        Complete markdown string
    """
    # Sort by order
    sorted_slides = sorted(slides, key=lambda s: s.get('order', 0))
    
    slide_markdowns = []
    for slide in sorted_slides:
        md = assemble_slide_markdown(
            slide.get('title'),
            slide.get('subtitle'),
            slide.get('content', '')
        )
        slide_markdowns.append(md)
    
    return '\n\n---\n\n'.join(slide_markdowns)

